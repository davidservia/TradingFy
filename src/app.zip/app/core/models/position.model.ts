export interface Position {
  id:number;
  docId:string;
  name: string;
  time: number;
  valor: number;
  userId: string;
  picture?: string;
}
