export interface Assign {
  id:number;
  docId:string;
  marketId:string;
  positionId:string;
  userId:string;
  createdAt:string;
  dateTime:string;
}
  /*
  2023-01-01T00:00:00+01:00
  ISO 8601 YYYY-MM-DDTHH:mm:ss+HH:MM
  */