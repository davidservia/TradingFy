export interface Market {
  id: number;
  docId:string;
  name: string;
  pais: string;
  userId:string;
  horario: string;
  picture: string;
}
